package borad_point;

import customer.CustomerDTO;

public interface AbstractPoint {
	int savePoint(CustomerDTO user);
}
