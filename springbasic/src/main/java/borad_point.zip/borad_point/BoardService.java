package borad_point;

public interface BoardService {
	void insertBoard(BoardDTO board);
}
