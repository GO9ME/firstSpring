package borad_point;

import customer.CustomerDAO;
import customer.CustomerDTO;
import customer.MyBatisCustomerDAO;

public class BoardServiceImpl implements BoardService {
	CustomerDAO dao = new MyBatisCustomerDAO();
	AbstractPoint ap = new PointImpl();

	@Override
	public void insertBoard(BoardDTO board) {
		// TODO Auto-generated method stub
		CustomerDTO dto  = dao.getUser(board.getId());
		System.out.println(dto);
		int point = ap.savePoint(dto);
		System.out.println(dto.getName()+"�� ����Ʈ�� : " + point);
	}

}
