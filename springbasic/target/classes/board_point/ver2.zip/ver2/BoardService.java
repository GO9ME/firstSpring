package board_point.ver2;

public interface BoardService {
	void insertBoard(BoardDTO board);
}
