package board_point.ver2;

import customer.CustomerDAO;
import customer.MyBatisCustomerDAO;

public class BoardFactory {
	public BoardService getBoardService() {
		CustomerDAO dao = new MyBatisCustomerDAO();
		AbstractPoint ap = new OtherPointImpl();
		return new BoardServiceImpl(dao,ap);
	}
}
