package board_point.ver2;

import customer.CustomerDTO;

public interface AbstractPoint {
	int savePoint(CustomerDTO user);
}
